# particle-system-starter
A starter project for a lesson on developing particle engines using MonoGame.

This starter project is for use in conjunction with the lesson presented in the Kansas State University CIS 580 Foundations of Game Programming Textbook.  The chapter in this open textbook can be accessed at [http://people.cs.ksu.edu/~nhbean/cis580/particle-systems](http://people.cs.ksu.edu/~nhbean/cis580/particle-systems).
