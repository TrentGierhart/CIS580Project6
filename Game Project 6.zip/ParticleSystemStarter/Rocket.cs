﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using System;

namespace ParticleSystemStarter
{
    public class Rocket
    {
        Game1 game;
        public BoundingCircle Bounds;
        Texture2D texture;
        Texture2D particleTexture;
        Player player;

        ParticleSystem trailSystem;
        ParticleSystem explosionSystem;
        Random random = new Random();

        float speed;
        public float life;

        public Rocket(Game1 game)
        {
            this.game = game;
            player = game.player;
        }

        public void LoadContent(ContentManager content)
        {
            texture = content.Load<Texture2D>("rocket");
            particleTexture = content.Load<Texture2D>("particle");
            
            //trail particle system
            trailSystem = new ParticleSystem(game.GraphicsDevice, 1000, particleTexture);
            trailSystem.SpawnPerFrame = 4;

            trailSystem.SpawnParticle = (ref Particle particle) =>
            {
                if (!Collisions.CollidesWith(Bounds, player.Bounds))
                {
                    particle.position = new Vector2(Bounds.X, Bounds.Y + 16);
                    particle.velocity = new Vector2(
                        MathHelper.Lerp(-5, 5, (float)random.NextDouble()),
                        MathHelper.Lerp(0, 100, (float)random.NextDouble())
                        );
                    particle.acceleration = 0.1f * new Vector2(0, (float)-random.NextDouble());
                    particle.color = Color.Blue;
                    particle.scale = 1f;
                    particle.life = 1.0f;
                }
            };

            trailSystem.UpdateParticle = (float deltaT, ref Particle particle) =>
            {
                particle.velocity += deltaT * particle.acceleration;
                particle.position += deltaT * particle.velocity;
                particle.scale -= deltaT;
                particle.life -= deltaT;
            };

            //explosion particle system
            explosionSystem = new ParticleSystem(game.GraphicsDevice, 1000, particleTexture);
            explosionSystem.SpawnPerFrame = 8;

            explosionSystem.SpawnParticle = (ref Particle particle) =>
            {
                if (Collisions.CollidesWith(Bounds, player.Bounds))
                {
                    particle.position = new Vector2(Bounds.X, Bounds.Y);
                    particle.velocity = new Vector2(
                        MathHelper.Lerp(-100, 100, (float)random.NextDouble()),
                        MathHelper.Lerp(-100, 100, (float)random.NextDouble())
                        );
                    particle.acceleration = 0.2f * new Vector2(0, (float)-random.NextDouble());
                    particle.color = Color.Green;
                    particle.scale = 1.5f;
                    particle.life = 1.0f;
                }
            };

            explosionSystem.UpdateParticle = (float deltaT, ref Particle particle) =>
            {
                particle.velocity += deltaT * particle.acceleration;
                particle.position += deltaT * particle.velocity;
                particle.scale -= deltaT;
                particle.life -= deltaT;
            };
        }

        public void Initialize()
        {
            speed = .4f;
            Bounds.X = MathHelper.Lerp(0, game.GraphicsDevice.Viewport.Width - 16, (float)random.NextDouble());
            Bounds.Y = game.GraphicsDevice.Viewport.Height + 32;
            life = 0.5f;
        }

        public void Update(GameTime gameTime)
        {
            if (life < 0)
            {
                game.RemoveRocket(this);
            }
            if (Bounds.Y < -48 || Bounds.Y > game.GraphicsDevice.Viewport.Height + 48)
            {
                speed = speed * -1;
            }
            explosionSystem.Update(gameTime);
            Bounds.Y -= (float)gameTime.ElapsedGameTime.TotalMilliseconds * speed;
            trailSystem.Update(gameTime);
            life -= gameTime.ElapsedGameTime.Seconds;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            trailSystem.Draw();
            explosionSystem.Draw();
            var source = new Rectangle(
                0, // X value 
                0, // Y value
                (int)((Rectangle)Bounds).Width, // Width 
                (int)((Rectangle)Bounds).Height // Height
                );

            // render the sprite
            spriteBatch.Draw(texture, new Vector2(Bounds.X, Bounds.Y), source, Color.White);
        }
    }
}
