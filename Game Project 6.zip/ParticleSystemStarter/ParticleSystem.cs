﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace ParticleSystemStarter
{
    public delegate void ParticleSpawner(ref Particle particle);
    public delegate void ParticleUpdater(float deltaT, ref Particle particle);

    class ParticleSystem
    {
        Particle[] particles;
        Texture2D texture;
        SpriteBatch spriteBatch;
        Random rand = new Random();
        int nextIndex = 0;

        public Vector2 Emitter { get; set; }
        public int SpawnPerFrame { get; set; }
        public ParticleSpawner SpawnParticle { get; set; }
        public ParticleUpdater UpdateParticle { get; set; }


        public ParticleSystem(GraphicsDevice graphicsDevice, int size, Texture2D t)
        {
            particles = new Particle[size];
            spriteBatch = new SpriteBatch(graphicsDevice);
            texture = t;
        }

        public void Update(GameTime gameTime)
        {
            if (SpawnParticle == null || UpdateParticle == null) return;

            //spawn new particles
            for (int i = 0; i < SpawnPerFrame; i++)
            {
                SpawnParticle(ref particles[nextIndex]);

                nextIndex++;
                if (nextIndex >= particles.Length) nextIndex = 0;
            }

            //update living particles
            float deltaT = (float)gameTime.ElapsedGameTime.TotalSeconds;
            for (int i = 0; i < particles.Length; i++)
            {
                if (particles[i].life <= 0) continue;

                UpdateParticle(deltaT, ref particles[i]);
            }
        }

        public void Draw()
        {
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.Additive);

            for (int i = 0; i < particles.Length; i++)
            {
                if (particles[i].life <= 0) continue;

                spriteBatch.Draw(texture, particles[i].position, null, particles[i].color,
                    0f, Vector2.Zero, particles[i].scale, SpriteEffects.None, 0);
            }

            spriteBatch.End();
        }


    }
}
