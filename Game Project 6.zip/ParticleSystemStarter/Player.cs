﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;

namespace ParticleSystemStarter
{
    public class Player
    {
        Game1 game;

        public BoundingRectangle Bounds;

        Texture2D texture;
        Texture2D particleTexture;

        ParticleSystem particleSystem;
        Random random = new Random();

        private float hSpeed;
        public float vSpeed;
        private float upSpeed;
        private float gravity;

        const int FRAME_HEIGHT = 126;
        int facing;

        public enum MoveState
        {
            Idle,
            Left,
            Right,
        }
        public MoveState state;

        public enum VerticalState
        {
            Up,
            Down
        }
        public VerticalState vState;

        public Player(Game1 game)
        {
            this.game = game;
        }

        public void LoadContent(ContentManager content)
        {
            texture = content.Load<Texture2D>("player");
            particleTexture = content.Load<Texture2D>("fire");
            particleSystem = new ParticleSystem(game.GraphicsDevice, 1000, particleTexture);
            particleSystem.SpawnPerFrame = 4;

            particleSystem.SpawnParticle = (ref Particle particle) =>
            {
                if (vState == VerticalState.Up)
                {
                    if (facing == 0)
                    {
                        particle.position = new Vector2(Bounds.X + 4, Bounds.Y + 68);
                    }
                    else
                    {
                        particle.position = new Vector2(Bounds.X + 44, Bounds.Y + 68);
                    }
                    particle.velocity = new Vector2(
                        MathHelper.Lerp(-50, 50, (float)random.NextDouble()),
                        MathHelper.Lerp(0, 100, (float)random.NextDouble())
                        );
                    particle.acceleration = 0.1f * new Vector2(0, (float)-random.NextDouble());
                    particle.color = Color.Firebrick;
                    particle.scale = 1f;
                    particle.life = 1.0f;
                }
            };

            particleSystem.UpdateParticle = (float deltaT, ref Particle particle) =>
            {
                particle.velocity += deltaT * particle.acceleration;
                particle.position += deltaT * particle.velocity;
                particle.scale -= deltaT;
                particle.life -= deltaT;
            };
        }

        public void Initialize()
        {
            hSpeed = .6f;
            upSpeed = 0f;
            vSpeed = 0.0f;
            gravity = 0.3f;
            Bounds.Width = 62;
            Bounds.Height = 126;
            Bounds.X = 0;
            Bounds.Y = game.GraphicsDevice.Viewport.Height - Bounds.Height - 100;
            state = MoveState.Idle;
            facing = 0;
        }

        public void Update(GameTime gameTime)
        {
            particleSystem.Update(gameTime);

            if (Bounds.X > game.GraphicsDevice.Viewport.Width - Bounds.Width)
            {
                Bounds.X = game.GraphicsDevice.Viewport.Width - Bounds.Width;
            }
            if (Bounds.X < 0)
            {
                Bounds.X = 0;
            }
            if (Bounds.Y > game.GraphicsDevice.Viewport.Height - Bounds.Height)
            {
                Bounds.Y = game.GraphicsDevice.Viewport.Height - Bounds.Height;
            }
            if (Bounds.Y < 0)
            {
                Bounds.Y = 0;
            }

            var keyboardState = Keyboard.GetState();

            if (vState == VerticalState.Down)
            {
                vSpeed += gravity;
                Bounds.Y += vSpeed;
            }

            if (keyboardState.IsKeyDown(Keys.Up))
            {
                if (upSpeed < 6f)
                {
                    upSpeed += 0.2f;
                }
                vSpeed = 0f;
                vState = VerticalState.Up;
                Bounds.Y -= upSpeed;
            }
            else
            {
                vState = VerticalState.Down;
                upSpeed = 0f;
            }

            // Move the player left if the left key is pressed
            if (keyboardState.IsKeyDown(Keys.Left))
            {
                // move left
                facing = 1;
                state = MoveState.Left;
                Bounds.X -= (float)gameTime.ElapsedGameTime.TotalMilliseconds * hSpeed;
            }

            // Move the player right if the right key is pressed
            if (keyboardState.IsKeyDown(Keys.Right))
            {
                // move right
                facing = 0;
                state = MoveState.Right;
                Bounds.X += (float)gameTime.ElapsedGameTime.TotalMilliseconds * hSpeed;
            }

            if (!(keyboardState.IsKeyDown(Keys.Left) || keyboardState.IsKeyDown(Keys.Right)))
            {
                state = MoveState.Idle;
            }

        }

        public void Draw(SpriteBatch spriteBatch)
        {
            particleSystem.Draw();
            var source = new Rectangle(
                0, // X value 
                facing * FRAME_HEIGHT, // Y value
                (int)Bounds.Width, // Width 
                (int)Bounds.Height // Height
                );

            // render the sprite
            spriteBatch.Draw(texture, new Vector2(Bounds.X, Bounds.Y), source, Color.White);
        }
    }
}
