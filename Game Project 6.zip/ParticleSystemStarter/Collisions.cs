﻿using System;

namespace ParticleSystemStarter
{
    public static class Collisions
    {
        /// <summary>
        /// Detects collisions between this BoundingCircle and a BoundingRectangle
        /// </summary>
        /// <param name="c">This BoundingCircle</param>
        /// <param name="r">The BoundingRectangle</param>
        /// <returns>true if there is a collision, false otherwise</returns>
        public static bool CollidesWith(this BoundingCircle c, BoundingRectangle r)
        {
            var closestX = Math.Max(Math.Min(c.X, r.X + r.Width), r.X);
            var closestY = Math.Max(Math.Min(c.Y, r.Y + r.Height), r.Y);
            return (Math.Pow(c.Radius, 2) >= Math.Pow(closestX - c.X, 2) + Math.Pow(closestY - c.Y, 2));
        }

        /// <summary>
        /// Detects collisions between this BoundingRectangle and another BoundingRectangle
        /// </summary>
        /// <param name="a">This BoundingRectangle</param>
        /// <param name="b">The other BoundingRectangle</param>
        /// <returns>true if there is a collision, false otherwise</returns>
        public static bool CollidesWith(this BoundingRectangle a, BoundingRectangle b)
        {
            return !(a.X > a.X + b.Width
                  || a.X + a.Width < b.X
                  || a.Y > b.Y + b.Height
                  || a.Y + a.Height < b.Y);
        }
    }
}
